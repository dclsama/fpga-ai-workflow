xsim {leg_mux_tb} -autoloadwcfg -tclbatch {run_sim.tcl}
