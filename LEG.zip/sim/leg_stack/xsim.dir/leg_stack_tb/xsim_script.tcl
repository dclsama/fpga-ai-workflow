xsim {leg_stack_tb} -autoloadwcfg -tclbatch {run_sim.tcl}
