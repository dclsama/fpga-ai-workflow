xsim {leg_regfile_tb} -autoloadwcfg -tclbatch {run_sim.tcl}
