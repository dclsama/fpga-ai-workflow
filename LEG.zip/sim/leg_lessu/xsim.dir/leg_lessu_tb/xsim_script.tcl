xsim {leg_lessu_tb} -autoloadwcfg -tclbatch {run_sim.tcl}
