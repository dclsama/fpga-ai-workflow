xsim {leg_register_tb} -autoloadwcfg -tclbatch {run_sim.tcl}
