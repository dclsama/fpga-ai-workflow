xsim {leg_dmem_tb} -autoloadwcfg -tclbatch {run_sim.tcl}
