xsim {leg_equal_tb} -autoloadwcfg -tclbatch {run_sim.tcl}
