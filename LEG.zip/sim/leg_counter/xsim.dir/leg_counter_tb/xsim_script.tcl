xsim {leg_counter_tb} -autoloadwcfg -tclbatch {run_sim.tcl}
