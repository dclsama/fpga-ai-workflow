xsim {leg_decoder3_tb} -autoloadwcfg -tclbatch {run_sim.tcl}
