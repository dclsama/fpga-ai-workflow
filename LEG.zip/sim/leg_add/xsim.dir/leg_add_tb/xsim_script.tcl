xsim {leg_add_tb} -autoloadwcfg -tclbatch {run_sim.tcl}
