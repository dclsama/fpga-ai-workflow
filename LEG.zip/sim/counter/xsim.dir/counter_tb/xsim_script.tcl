xsim {counter_tb} -autoloadwcfg -tclbatch {run_sim.tcl}
