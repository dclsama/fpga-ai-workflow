xsim {leg_core_tb} -autoloadwcfg -tclbatch {run_sim.tcl}
