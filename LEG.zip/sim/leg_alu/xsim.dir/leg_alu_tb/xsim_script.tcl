xsim {leg_alu_tb} -autoloadwcfg -tclbatch {run_sim.tcl}
