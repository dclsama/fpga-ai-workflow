xsim {leg_pc_tb} -autoloadwcfg -tclbatch {run_sim.tcl}
