xsim {leg_decoder_tb} -autoloadwcfg -tclbatch {run_sim.tcl}
